Welcome to IP1

To download the dependencies, run:

```
npm install
```
You shold have node v18 instqalled.

To compile the typescript code:
```
npm run buil
```

To lint your code:
```
npm run lint
```
You will see some messages, part of your job is to make the go away.

To test you code:
```
npm test
```
There will be errors, again your job is to make them go away.



