import IClock from "./IPullingClock";

export class SimpleClock implements IClock {
    private time = 0

    public reset () : void {this.time = 0}

    public tick () : void { this.time++ }

    public getTime(): number { return this.time }
}

export class ClockClient {
    constructor (private theclock:IClock) {}

    getTimeFromClock ():number {return this.theclock.getTime()}
}

