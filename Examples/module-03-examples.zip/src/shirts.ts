type Shirt = {
    /** the color of the shirt */
    color: Color 
}

type Color = { /* ... */}

/** My shirt */
const myShirt: Shirt 

myShirt.color = red
