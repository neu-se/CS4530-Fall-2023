import axios from 'axios'

async function echo(str: string) : Promise<string> {
    const res = 
        await axios.get(`https://httpbin.org/get?answer=${str}`)
    return res.data.args.answer
}

test('request should return its argument', async () => {
    expect.assertions(1)
    await expect(echo("33")).resolves.toEqual("33")
})