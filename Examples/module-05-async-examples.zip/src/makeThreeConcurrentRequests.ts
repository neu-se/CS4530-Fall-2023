import makeOneGetRequest from './run-to-completion/makeOneGetRequest'
import timeIt from './run-to-completion/timeIt'

async function makeThreeConcurrentRequests(): Promise<void> {
    await Promise.all([
        makeOneGetRequest(1),
        makeOneGetRequest(2),
        makeOneGetRequest(3)
    ])
    console.log('Heard back from all of the requests')
}

timeIt("main thread", makeThreeConcurrentRequests)
