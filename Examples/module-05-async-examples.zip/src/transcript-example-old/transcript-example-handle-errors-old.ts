import axios from 'axios';
import { promises as fsPromises } from 'fs';

function dataFileName(studentID:number):string {
    return `transcript-${studentID}.json`
}

// works on any array of summable things.
function sum(numbers:any[]):number {
    return numbers.reduce((runningTotal, val) => runningTotal + val.size, 0);
}

/** returns a promise to return the student data */
async function StudentDataPromise (studentID: number) : Promise<any> {
    try {
    const returnValue = await axios.get(`https://rest-example.covey.town/transcripts/${studentID}`)
    return {isOk: true, id: studentID, value: returnValue}
    } catch (e) {
        return {isOK: false, id: studentID}
    }

}

/** returns a promise to write the transcript file */
async function WriteTranscriptPromise(studentID: number) : Promise<void> {
    // create a (sub)promise and wait for the result
    const response = await StudentDataPromise(studentID) 
    if (!(response.isOK)) {
            console.log(`bad student ID ${studentID}`)
            return
    }     
    await fsPromises.writeFile(
        dataFileName(response.data.student.studentID),        
        JSON.stringify(response.data))
    }
  
async function runClientAsync(studentIDs:number[]) {
    console.log(`Generating Promises for ${studentIDs}`); 
    const promisesForTranscripts =  studentIDs.map(studentID => WriteTranscriptPromise(studentID)) ;  
    console.log('Promises Created! ');
    console.log('Wait for all promises to be satisfied')
    await Promise.all(promisesForTranscripts);
    console.log('Files written!')
    const promisesForStats = 
        studentIDs.map(studentID => fsPromises.stat(dataFileName(studentID)))
    const stats =  await Promise.all(promisesForStats)       
    const totalSize = sum(stats)
    console.log(`Finished calculating size: ${totalSize}`);
    console.log('Done');
  }

  // these are IDs that happen to be in the db as of 11/14/22
  runClientAsync([411,32789,412,423,10202040])

  