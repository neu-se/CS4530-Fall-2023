class Clock1 {
  private time = 0;

  public reset(): void {
    this.time = 0;
  }

  public tick(): void {
    this.time++;
  }

  public getTime(): number {
    return this.time;
  }
}

const source1 = new Clock1();

function testGetTime(correctValue: number) {
  test(`After ${correctValue} ticks, getTime should return ${correctValue}`, () => {
    expect(source1.getTime()).toEqual(correctValue);
  });
}

describe('tests of Clock1', () => {
  test('after reset, clock should return 0', () => {
    source1.reset();
    expect(source1.getTime()).toBe(0);
  });
  test('after one tick, getTime should return 1', () => {
    source1.reset();
    source1.tick();
    expect(source1.getTime()).toBe(1);
  });

  test('after two ticks, getTime should return 2', () => {
    source1.reset();
    source1.tick();
    source1.tick();
    expect(source1.getTime()).toBe(2);
  });
});

// describe("test multiple clicks", () => {
//     testClock()
