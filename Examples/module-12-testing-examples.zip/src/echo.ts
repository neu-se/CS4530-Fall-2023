import axios from 'axios';

export async function echo(str: string): Promise<string> {
  const res = await axios.get(`https://httpbin.org/get?answer=${str}`);
  return res.data.args.answer;
}
