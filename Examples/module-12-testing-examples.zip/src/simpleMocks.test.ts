test('simplest mock behavior', () => {
  const mockFunction1 = jest.fn();

  const result1 = mockFunction1('foo');
  const result2 = mockFunction1('bar');
  expect(result1).toBeUndefined();
  expect(result2).toBeUndefined();
  expect(mockFunction1).toHaveBeenCalled();
  expect(mockFunction1).toHaveBeenCalledTimes(2);
  expect(mockFunction1).toHaveBeenCalledWith('foo');
  expect(mockFunction1).toHaveBeenCalledWith('bar');
});

test('customizing mock functions', () => {
  // you can specify the the return value
  const mockFunction3 = jest.fn();
  mockFunction3.mockReturnValue('baz');

  expect(mockFunction3('foo')).toBe('baz');
  expect(mockFunction3).toHaveBeenCalledWith('foo');

  // or give the mock an implementation
  const mockFunction2 = jest.fn();
  mockFunction2.mockImplementation((n: number) => n + n);

  expect(mockFunction2(3)).toBe(6);
  expect(mockFunction2(14)).toBe(28);
  expect(mockFunction2).toHaveBeenCalledWith(3);
  expect(mockFunction2).toHaveBeenCalledWith(14);

  // you can reset the mock's history
  mockFunction2.mockReset();
  expect(mockFunction2).not.toHaveBeenCalledWith(14);
});

test('mock implementation', () => {
  const mock1 = jest.fn((x) => 'bar');
  expect(mock1('foo')).toBe('bar');
  expect(mock1).toHaveBeenCalledWith('foo');
});

test('also mock implementation', () => {
  const mock = jest.fn().mockImplementation(() => 'bar');

  expect(mock('foo')).toBe('bar');
  expect(mock).toHaveBeenCalledWith('foo');
});

test('mock implementation one time', () => {
  const mock = jest.fn().mockImplementationOnce(() => 'bar');

  expect(mock('foo')).toBe('bar');
  expect(mock).toHaveBeenCalledWith('foo');

  expect(mock('baz')).toBe(undefined);
  expect(mock).toHaveBeenCalledWith('baz');
});

test('mock return value', () => {
  const mock = jest.fn();
  mock.mockReturnValue('bar');

  expect(mock('foo')).toBe('bar');
  expect(mock).toHaveBeenCalledWith('foo');
});

test('mock promise resolution', () => {
  const mock = jest.fn();
  mock.mockResolvedValue('bar');

  expect(mock('foo')).resolves.toBe('bar');
  expect(mock).toHaveBeenCalledWith('foo');
});
