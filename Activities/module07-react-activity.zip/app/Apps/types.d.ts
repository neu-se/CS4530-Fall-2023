export type ToDoItem = {
    title: string; 
    priority: string
    id: string;
  };

  export type ClockDisplayData = {
    title: string;
    key: number
    clock: Clock}