import * as React from 'react';
import { useState, useEffect } from 'react';
import {
  Heading, Table, Th, Tbody, Tr,
  Td,
  VStack, 
} from '@chakra-ui/react';

type ClockDisplayData = {key:number, name:string, noisyDelete?:boolean}

import { ClockDisplay } from './SimpleClockDisplay'

function makeClockDisplayData(key:number) { 
    return {key:key, name:'clock ' + key, noisyDelete: true}
}

export default function App () {
    const [clockDisplays, setClockDisplays] = useState<ClockDisplayData[]>([])
    const [nextKey, setNextKey] = useState(1)

    // add a clock display on first render
    useEffect(() => {handleAdd()}, [])
        

    function handleAdd() {
        setClockDisplays(clockDisplays.concat(makeClockDisplayData(nextKey)))
        setNextKey(nextKey+1)
    }

    function handleDelete(targetKey:number) {
        const newList = clockDisplays.filter(item => item.key != targetKey)
        setClockDisplays(newList)
    }   

    function displayOneClock(clockDisplayData:ClockDisplayData) {
        return (
            <Tr key={clockDisplayData.key}>
                <Td>
                    <ClockDisplay name={clockDisplayData.name} key={clockDisplayData.key} 
                        handleDelete={() => handleDelete(clockDisplayData.key)} 
                        handleAdd={handleAdd}
                        noisyDelete={clockDisplayData.noisyDelete}
                    />
                </Td>
            </Tr>
        )
    }

    return (
        <VStack>
            <Heading>Array of Clock Displays</Heading>
            <Table>
                <Tbody>
                    {clockDisplays.map((clockDisplayData) => displayOneClock(clockDisplayData))}
                </Tbody>
            </Table>
        </VStack>
    )
}