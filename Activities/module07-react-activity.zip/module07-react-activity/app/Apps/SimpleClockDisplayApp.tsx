import * as React from 'react';
import { useState } from 'react';
import {
  Box,
  Button,
  VStack,
} from '@chakra-ui/react'

import { ClockDisplay } from './SimpleClockDisplay'

function doNothing() { }

export default function App() {
  return (<VStack>
    <ClockDisplay name={'Clock A'} key = {1} handleAdd={doNothing} handleDelete={doNothing}/>
    <ClockDisplay name={'Clock B'} key = {2} handleAdd={doNothing} handleDelete={doNothing} />
    <ClockDisplay name={'Clock C'} key = {3} handleAdd={doNothing} handleDelete={doNothing}/>
  </VStack>)
}